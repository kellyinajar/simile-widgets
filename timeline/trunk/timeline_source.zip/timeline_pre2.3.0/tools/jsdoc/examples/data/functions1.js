﻿function recast(employeeId, newRole) {
}

refresh = function(record) {
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "undocumented",
                alias: "recast",
                memberof: "",
                params: [
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "employeeId",
                        isOptional: false
                    },
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "newRole",
                        isOptional: false
                    }
                ],
                methods: [],
                name: "recast"
            },
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "undocumented",
                alias: "refresh",
                memberof: "",
                params: [
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "record",
                        isOptional: false
                    }
                ],
                methods: [],
                name: "refresh"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/functions1.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/functions1.js"
        }
    }
]
*/