/**
 * @fileOverview A collection of functions for records.
 * @name Record Keeper
 */
 
/** 
 * Gets the current record. 
 */
function getRecord(){
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "Gets the current record.",
                alias: "getRecord",
                memberof: "",
                params: [],
                methods: [],
                name: "getRecord"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "A collection of functions for records.",
            alias: "examples/data/overview.js",
            memberof: "",
            params: [],
            methods: [],
            name: "Record Keeper"
        }
    }
]
*/